package dev.lelonio.square.playback

import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * How loud the music is just now, and when its beats land.
 *
 * Fed with the sound on its way out, from both engines, and read by whatever
 * wants to move with the music: today the light that runs round the mini
 * player. It only listens: nothing is changed in the audio, and the cost is one
 * pass over every other sample of each buffer.
 *
 * Two things come out of it:
 *  - [level]: 0 to 1, how strong the sound is, smoothed so it breathes rather than flickers;
 *  - [kick]: 0 to 1, a pulse that jumps at each beat of the bass and dies away in
 *    a fraction of a second.
 *
 * The sound is read before it is heard: the audio track holds a few tenths of a
 * second ahead of the speaker. Beats are therefore dated [OUTPUT_DELAY_MS] later
 * than they were read, so the light lands with the beat and not before it.
 */
object AudioPulse {

    @Volatile private var smoothLevel = 0f
    @Volatile private var fedAt = 0L
    @Volatile private var beatAt = 0L
    @Volatile private var beatStrength = 0f

    // Only touched by whichever thread is feeding.
    private var lowPass = 0f
    private var lowAverage = 0f
    private var lastBeatRead = 0L

    /** In place and read only: [sizeInBytes] bytes of 16-bit little-endian PCM. */
    fun feed(data: ByteBuffer, sizeInBytes: Int, channels: Int, sampleRate: Int) {
        if (channels < 1 || sampleRate <= 0) return
        val shorts = data.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val frames = minOf(sizeInBytes / 2, shorts.limit()) / channels
        if (frames <= 0) return

        val rate = sampleRate.toFloat() / STRIDE
        val coef = 1f - exp(-2f * PI.toFloat() * BASS_HZ / rate)
        var all = 0f
        var low = 0f
        var counted = 0
        var i = 0
        while (i < frames) {
            val left = shorts.get(i * channels).toFloat()
            val right = if (channels > 1) shorts.get(i * channels + 1).toFloat() else left
            val mono = (left + right) * (0.5f / 32768f)
            lowPass += coef * (mono - lowPass)
            all += mono * mono
            low += lowPass * lowPass
            counted++
            i += STRIDE
        }
        if (counted == 0) return

        val seconds = frames / sampleRate.toFloat()
        val rms = sqrt(all / counted)
        val bass = sqrt(low / counted)

        // How strong: quick to rise, slower to fall.
        val target = (rms * LEVEL_GAIN).coerceIn(0f, 1f)
        val rate2 = if (target > smoothLevel) 14f else 5f
        smoothLevel += (target - smoothLevel) * (1f - exp(-seconds * rate2))

        // A beat is the bass standing well above where it has lately been.
        val now = SystemClock.uptimeMillis()
        lowAverage += (bass - lowAverage) * (1f - exp(-seconds / 1.2f))
        if (bass > lowAverage * BEAT_RATIO + BEAT_FLOOR && now - lastBeatRead > BEAT_GAP_MS) {
            lastBeatRead = now
            beatStrength = ((bass / lowAverage.coerceAtLeast(0.001f)) - 1f).coerceIn(0.35f, 1f)
            beatAt = now + OUTPUT_DELAY_MS
        }
        fedAt = now
    }

    /** 0 to 1, how strong the sound is; 0 once nothing has been fed for a moment. */
    fun level(): Float {
        val age = SystemClock.uptimeMillis() - fedAt
        return when {
            age > STALE_MS -> 0f
            age > STALE_MS / 2 -> smoothLevel * (1f - (age - STALE_MS / 2f) / (STALE_MS / 2f))
            else -> smoothLevel
        }
    }

    /** 0 to 1, jumps at each beat and fades in about a fifth of a second. */
    fun kick(): Float {
        val since = SystemClock.uptimeMillis() - beatAt
        if (since < 0 || since > 900) return 0f
        return beatStrength * exp(-since / KICK_DECAY_MS)
    }

    private const val STRIDE = 2
    private const val BASS_HZ = 150f
    private const val LEVEL_GAIN = 4f
    private const val BEAT_RATIO = 1.3f
    private const val BEAT_FLOOR = 0.008f
    private const val BEAT_GAP_MS = 220L
    private const val OUTPUT_DELAY_MS = 170L
    private const val STALE_MS = 500L
    private const val KICK_DECAY_MS = 170f
}
