package dev.lelonio.square.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext

/**
 * Keeps the screen on while [active]: for a video, which is watched and not
 * touched, and which the phone's own timeout would otherwise dim and lock a
 * minute in.
 *
 * Done on the window rather than on a view, so it cannot be undone by another
 * part of the app that keeps the screen on for its own reason, such as the
 * lyrics; either one is enough, and neither takes the other's away.
 */
@Composable
fun KeepScreenOn(active: Boolean) {
    val context = LocalContext.current
    DisposableEffect(context, active) {
        var host: Context = context
        while (host is ContextWrapper && host !is Activity) host = host.baseContext
        val window = (host as? Activity)?.window
        if (active) {
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        // Let go the moment the video stops or is paused (or this leaves the
        // screen), so the phone can sleep again on its own timeout.
        onDispose {
            if (active) {
                window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }
}
