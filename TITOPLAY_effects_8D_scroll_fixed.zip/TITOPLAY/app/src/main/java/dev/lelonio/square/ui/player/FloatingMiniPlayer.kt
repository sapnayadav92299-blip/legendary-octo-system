/*
 * Adapted from Convx (GPL-3.0), ui/player/FloatingMiniPlayer.kt.
 * https://github.com/cosmictaserdev-creator/Convx
 *
 * Their accessory strip, with their sizes, their press response, their glow and
 * their swipe-to-skip, driven by this app's own playback state instead of
 * Convx's PlayerConnection. What is gone is what belonged to their app and not
 * to the shape of the thing: listen-together, the tablet pill that scales with
 * its height, the queue and lyrics buttons, and the preference keys behind the
 * gesture. The rest is theirs.
 */

@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package dev.lelonio.square.ui.player

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.basicMarquee
import dev.lelonio.square.ui.components.marqueeFade
import androidx.compose.foundation.layout.width
import dev.lelonio.square.ui.components.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adamglin.PhosphorIcons
import com.adamglin.phosphoricons.Regular
import com.adamglin.phosphoricons.regular.Sparkle
import com.adamglin.phosphoricons.Fill
import com.adamglin.phosphoricons.fill.Devices
import com.adamglin.phosphoricons.fill.Pause
import com.adamglin.phosphoricons.fill.Play
import com.adamglin.phosphoricons.fill.SkipForward
import dev.lelonio.square.R
import dev.lelonio.square.ui.glass.InteractiveHighlight
import dev.lelonio.square.ui.glass.ScrollingWaveformSeekBar
import dev.lelonio.square.ui.components.Artwork
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** Their numbers: a 40dp thumbnail, 40dp controls, 12 by 8 of padding. */
private val ArtSize = 40.dp
private val ControlSize = 40.dp

/**
 * What is playing, as the bar's accessory.
 *
 * The pill above the tabs when the bar is open and one of the three things on
 * the row when it has folded — the bar decides which, this only draws it.
 */
@Composable
fun FloatingMiniPlayer(
    state: PlaybackState,
    positionMs: State<Long>,
    modifier: Modifier = Modifier,
    contentColor: androidx.compose.ui.graphics.Color = MiniPlayerInk,
    /**
     * Where the music is coming out, when it is not this phone.
     *
     * Takes the artist's place on the second line, the way the old bar did it:
     * with playback on a speaker in another room, whose record it is matters
     * less than which room, and the screen was saying nothing about it at all.
     */
    remoteLabel: String? = null,
    /** Spotify's DJ is talking: its lights in place of the cover; see DjVoice. */
    djSpeaking: Boolean = false,
    /** Folded: the strip has room for the song and one button, nothing else. */
    inline: Boolean = false,
    collapseProgress: Float? = null,
    onClick: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
) {
    val fold = (collapseProgress ?: if (inline) 1f else 0f).coerceIn(0f, 1f)
    val artSize = androidx.compose.ui.unit.lerp(ArtSize, 36.dp, fold)
    val controlSize = androidx.compose.ui.unit.lerp(ControlSize, 36.dp, fold)
    val scope = rememberCoroutineScope()
    val layoutDirection = LocalLayoutDirection.current

    // iOS 26 style press response: the whole glass pill grows slightly while
    // touched.
    val pressInteractionSource = remember { MutableInteractionSource() }
    val isPressed by pressInteractionSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 1.04f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "accessoryPressScale",
    )

    // The same finger-tracking glow the tab bar's puck has. Its gesture tracking
    // never consumes pointer events, so it is safe stacked alongside the swipe
    // detector and the click below.
    val glow = remember(scope) { InteractiveHighlight(animationScope = scope) }
    val haloColor = androidx.compose.material3.MaterialTheme.colorScheme.primary

    val offsetX = remember { Animatable(0f) }
    val settle = remember { spring<Float>(stiffness = Spring.StiffnessMediumLow) }
    // Read at the moment of the gesture, not when it started: the detector
    // below is never restarted, so a song that changes under a swipe cannot
    // cut it short, and what the swipe decides on is always the latest.
    val latestState = androidx.compose.runtime.rememberUpdatedState(state)
    val latestNext = androidx.compose.runtime.rememberUpdatedState(onNext)
    val latestPrevious = androidx.compose.runtime.rememberUpdatedState(onPrevious)

    Box(
        contentAlignment = Alignment.CenterStart,
        modifier = Modifier
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .then(modifier)
            .then(glow.modifier)
            // A light round the edge while music plays, quicker with the beat. Out
            // here, before the clip below, so what spills past the pill's own edge
            // as a glow is not cut off at it.
            .neonRing(active = state.isPlaying && !djSpeaking)
            .clipToBounds()
            // A thin halo of the cover's own colour: a wash from the cover's
            // side and a hairline around the pill.
            .drawWithContent {
                drawContent()
                if (!djSpeaking) {
                    val r = size.height / 2f
                    drawRect(
                        androidx.compose.ui.graphics.Brush.horizontalGradient(
                            listOf(haloColor.copy(alpha = 0.16f), androidx.compose.ui.graphics.Color.Transparent),
                            endX = size.width * 0.55f,
                        ),
                    )
                    drawRoundRect(
                        color = haloColor.copy(alpha = 0.40f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(1.2.dp.toPx()),
                    )
                }
            }
            .then(glow.gestureModifier)
            .pointerInput(Unit) {
                // The distance travelled is kept here, as it happens, not read
                // back from the animated offset: that is moved by coroutines
                // that may not have run yet when the finger lifts, and a
                // swipe judged on a stale offset is what made this work only
                // some of the time.
                var total = 0f
                var startedAt = 0L
                detectHorizontalDragGestures(
                    onDragStart = {
                        total = 0f
                        startedAt = System.currentTimeMillis()
                    },
                    onDragCancel = {
                        total = 0f
                        scope.launch { offsetX.animateTo(0f, settle) }
                    },
                    onHorizontalDrag = { change, amount ->
                        change.consume()
                        val delta = if (layoutDirection == LayoutDirection.Rtl) -amount else amount
                        val next = total + delta
                        val live = latestState.value
                        val canGo = if (next > 0f) live.hasPrevious else live.hasNext
                        // Where there is nowhere to go the pill stays put, but
                        // on the way home it always follows the finger.
                        if (canGo || abs(next) < abs(total)) total = next
                        scope.launch { offsetX.snapTo(total) }
                    },
                    onDragEnd = {
                        val ms = System.currentTimeMillis() - startedAt
                        val far = abs(total)
                        // Mean speed over the gesture, px/ms: a short quick
                        // throw should not have to cross much of the pill.
                        val speed = if (ms > 0) far / ms else 0f
                        val threshold = size.width * 0.18f
                        if (far > threshold || (speed > 0.30f && far > 40f)) {
                            val live = latestState.value
                            if (total > 0f && live.hasPrevious) latestPrevious.value.invoke()
                            else if (total <= 0f && live.hasNext) latestNext.value.invoke()
                        }
                        total = 0f
                        scope.launch { offsetX.animateTo(0f, settle) }
                    },
                )
            },
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .offset { IntOffset(offsetX.value.roundToInt(), 0) }
                .clickable(
                    interactionSource = pressInteractionSource,
                    indication = null,
                    onClick = onClick,
                )
                .padding(
                    horizontal = androidx.compose.ui.unit.lerp(12.dp, 10.dp, fold),
                    vertical = androidx.compose.ui.unit.lerp(8.dp, 6.dp, fold),
                ),
        ) {
            if (djSpeaking) {
                DjVoice(
                    Modifier
                        .size(artSize)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(9.dp)),
                )
            } else Artwork(
                url = state.artworkUrl,
                title = state.title,
                modifier = Modifier.size(artSize),
                corner = 9.dp,
                decodeSize = ArtSize,
            )

            Spacer(Modifier.width(androidx.compose.ui.unit.lerp(10.dp, 8.dp, fold)))

            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (state.smartRecommended) Icon(
                        PhosphorIcons.Regular.Sparkle,
                        contentDescription = null,
                        tint = contentColor,
                        modifier = Modifier.padding(end = 4.dp).size(14.dp),
                    )
                // Its ends melt away as it glides, rather than being cut off.
                val titleFade = dev.lelonio.square.ui.components.rememberMarqueeFade(state.title, 2000L)
                Text(
                    text = state.title,
                    onTextLayout = { titleFade.textWidth = it.size.width },
                    style = androidx.compose.ui.text.lerp(
                        MaterialTheme.typography.bodyMedium,
                        MaterialTheme.typography.bodySmall,
                        fold,
                    ),
                    color = contentColor,
                    maxLines = 1,
                    // A title too long for the pill glides past, after a pause,
                    // rather than ending in dots; one that fits stays put.
                    softWrap = false,
                    overflow = TextOverflow.Clip,
                    modifier = Modifier
                        .marqueeFade(titleFade)
                        .basicMarquee(iterations = Int.MAX_VALUE, initialDelayMillis = 2000, velocity = 26.dp),
                )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // The DJ choosing, and talking; see DjMark.
                    if (remoteLabel == null && isDjQueue(state.contextUri)) {
                        DjMark(
                            color = contentColor,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(end = 5.dp),
                        )
                    }
                    if (remoteLabel != null) {
                        Icon(
                            PhosphorIcons.Fill.Devices,
                            contentDescription = null,
                            tint = MiniPlayerAccent,
                            modifier = Modifier
                                .size(androidx.compose.ui.unit.lerp(12.dp, 10.dp, fold))
                                .padding(end = 0.dp),
                        )
                    }
                    Text(
                        text = remoteLabel ?: state.artist,
                        style = androidx.compose.ui.text.lerp(
                            MaterialTheme.typography.bodySmall,
                            MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                            fold,
                        ),
                        color = if (remoteLabel != null) {
                            MiniPlayerAccent
                        } else {
                            contentColor.copy(alpha = 0.7f)
                        },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = if (remoteLabel != null) 4.dp else 0.dp),
                    )
                }
            }

            // Skip first and play second, which is the order asked for: the
            // button that starts the music is the one nearest the thumb.
            if (fold < 1f) {
                IconButton(onClick = onNext, enabled = fold < 0.5f,
                    modifier = Modifier.width(ControlSize * (1f - fold)).height(controlSize)
                        .graphicsLayer { alpha = 1f - fold }.clipToBounds()) {
                    Icon(
                        PhosphorIcons.Fill.SkipForward,
                        contentDescription = stringResource(R.string.next),
                        tint = contentColor,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }

            IconButton(
                onClick = onTogglePlay,
                modifier = Modifier.size(controlSize),
            ) {
                // The same ring the full player draws, for the same reason: a
                // track being fetched can take long enough that a tap on play
                // looks like nothing happened. Around the icon rather than in
                // its place, so the button stays where it is and stays pressable.
                Box(contentAlignment = Alignment.Center) {
                    if (state.isBuffering) {
                        CircularProgressIndicator(
                            color = contentColor.copy(alpha = 0.5f),
                            strokeWidth = 1.5.dp,
                            modifier = Modifier.size(androidx.compose.ui.unit.lerp(34.dp, 30.dp, fold)),
                        )
                    }
                    Icon(
                        if (state.wantsPlay) PhosphorIcons.Fill.Pause else PhosphorIcons.Fill.Play,
                        contentDescription = stringResource(
                            if (state.wantsPlay) R.string.pause else R.string.play,
                        ),
                        tint = contentColor,
                        modifier = Modifier.size(androidx.compose.ui.unit.lerp(24.dp, 20.dp, fold)),
                    )
                }
            }
        }

        // The old bar's own hairline, back where the wave was: a coloured line
        // along the bottom of the pill. It says where the track is without
        // asking to be read, which on a strip this size is the whole job.
        androidx.compose.material3.LinearProgressIndicator(
            progress = {
                val duration = state.durationMs
                if (duration > 0) (positionMs.value.toFloat() / duration).coerceIn(0f, 1f) else 0f
            },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .height(2.dp),
            color = MaterialTheme.colorScheme.primary,
            trackColor = contentColor.copy(alpha = 0.18f),
            drawStopIndicator = {},
        )
    }
}
