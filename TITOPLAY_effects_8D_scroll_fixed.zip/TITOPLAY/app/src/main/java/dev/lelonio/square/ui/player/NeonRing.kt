package dev.lelonio.square.ui.player

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import dev.lelonio.square.playback.AudioPulse
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow

/**
 * A neon light that runs round the edge of the pill while music plays.
 *
 * Drawn the way a gradient is drawn, not as a string of beads. The outline of a
 * pill is two straight sides and two half circles, and along each of those the
 * position on the outline is exactly a position on one gradient: a linear one
 * along a straight side, a sweep one round a half circle. So the light is laid
 * down as four unbroken strokes, each filled with one gradient that carries the
 * colour and the fade for that stretch: no pieces, no joins, no dots, and the
 * same smoothness at any size.
 *
 * Built like a neon tube: a thin crisp tube of colour with a hotter, nearly white
 * centre, and round it two soft layers of glow that add their light to what is
 * behind, the wider spilling outside the pill's edge. The colour is a flowing run
 * of the palette (blue, violet, pink, amber, green, cyan, and round again) that
 * slides along all the time. Behind a bright head the tube thins and fades away
 * to nothing. There are two lights, half a lap apart and in different parts of
 * the palette: two thin lines with dark edge between them.
 *
 * The music drives it: the lights run round faster as the sound gets stronger
 * and are thrown forward on every beat of the bass, their tails lengthen, the
 * glow swells and the tube swells a little with each beat, and the colours run
 * through the palette quicker. See [AudioPulse].
 *
 * It follows the outline at an even speed, takes no touches, and when the music
 * stops it fades out and its frame loop stops with it.
 *
 * Drawn on the edge and past it, so it has to be put outside anything that clips
 * to the pill's own bounds.
 */
@Composable
fun Modifier.neonRing(active: Boolean): Modifier {
    var lap by remember { mutableFloatStateOf(0f) }
    var hue by remember { mutableFloatStateOf(0f) }
    var glow by remember { mutableFloatStateOf(0f) }
    var reach by remember { mutableFloatStateOf(0f) }
    var pulse by remember { mutableFloatStateOf(0f) }
    val appear by animateFloatAsState(
        targetValue = if (active) 1f else 0f,
        animationSpec = tween(450),
        label = "neon-appear",
    )

    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        var last = 0L
        var speed = BASE_LAPS
        var drift = BASE_DRIFT
        while (true) {
            val frame = withFrameNanos { it }
            val dt = if (last == 0L) 0f else ((frame - last) / 1_000_000_000f).coerceAtMost(0.05f)
            last = frame

            val level = AudioPulse.level()
            val kick = AudioPulse.kick()

            // Laps a second: brisk even when the music is soft, fast when it is
            // strong, and thrown forward on a beat. Eased, so a change is felt
            // as a surge and never as a jump.
            val wanted = BASE_LAPS + LEVEL_LAPS * level + KICK_LAPS * kick
            speed += (wanted - speed) * (1f - exp(-dt * 9f))
            lap = (lap + speed * dt) % 1f

            // Runs of the palette a second: the colours are always on the move.
            val drifting = BASE_DRIFT + LEVEL_DRIFT * level + KICK_DRIFT * kick
            drift += (drifting - drift) * (1f - exp(-dt * 6f))
            hue = (hue + drift * dt) % 1f

            val light = (0.45f + 0.55f * level + 0.5f * kick).coerceAtMost(1f)
            glow += (light - glow) * (1f - exp(-dt * 12f))
            val length = (0.45f * level + kick).coerceAtMost(1f)
            reach += (length - reach) * (1f - exp(-dt * 8f))
            // The beat itself, quicker to rise than to fall: what swells the tube.
            pulse += (kick - pulse) * (1f - exp(-dt * (if (kick > pulse) 30f else 10f)))
        }
    }

    return this.drawWithCache {
        val w = size.width
        val h = size.height
        val radius = h / 2f
        val straight = w - 2f * radius
        val core = CORE.toPx()

        // The four stretches of the outline, clockwise from the left end of the top
        // side, each with the distance along the outline at which it begins.
        val sections = if (straight > 1f && radius > 0f) buildSections(w, h, radius, straight) else emptyList()
        val perimeter = 2f * straight + 2f * PI.toFloat() * radius

        onDrawWithContent {
            drawContent()
            if (appear <= 0.01f || sections.isEmpty()) return@onDrawWithContent

            val strength = appear * (0.78f + 0.22f * glow)
            // Short enough that the two lights are two lines with the dark edge
            // between them: even at their longest they do not meet.
            val tail = perimeter * (0.22f + 0.13f * reach)
            val head = lap * perimeter
            val swell = 1f + 0.35f * pulse

            val first = Comet(perimeter, head, tail, strength, hue)
            val second = Comet(perimeter, (head + perimeter / 2f) % perimeter, tail, strength, hue + 0.5f)
            for (comet in listOf(first, second)) {
                // Widest and faintest first, so what is brightest is on top.
                paint(sections, comet, core * 5.2f * swell, alpha = 0.16f, whiten = 0f, reachOf = 1f, blend = BlendMode.Plus)
                paint(sections, comet, core * 2.6f * swell, alpha = 0.30f, whiten = 0f, reachOf = 1f, blend = BlendMode.Plus)
                paint(sections, comet, core * 0.62f * swell, alpha = 1f, whiten = 0f, reachOf = 1f, blend = BlendMode.SrcOver)
                paint(sections, comet, core * swell, alpha = 1f, whiten = 0f, reachOf = 0.55f, blend = BlendMode.SrcOver)
                paint(sections, comet, core * 0.42f * swell, alpha = 0.85f, whiten = 0.7f, reachOf = 0.4f, blend = BlendMode.SrcOver)
            }
        }
    }
}

// ---------------------------------------------------------------------------
// The outline, in four stretches

/** One stretch of the outline: a straight side or a half circle. */
private class Section(
    val path: Path,
    /** Distance along the outline at which it begins. */
    val start: Float,
    val length: Float,
    val straight: Boolean,
    // A straight side: the two ends of the line, a hair longer than the side.
    val ax: Float = 0f,
    val ay: Float = 0f,
    val bx: Float = 0f,
    val by: Float = 0f,
    // A half circle: its centre, its radius, and the angle at which it begins.
    val cx: Float = 0f,
    val cy: Float = 0f,
    val radius: Float = 0f,
    val firstDegrees: Float = 0f,
)

/** How much longer than its side a straight stroke is, at each end, so that no seam shows where it meets the curve. */
private const val OVERLAP = 0.8f

private fun buildSections(w: Float, h: Float, r: Float, straight: Float): List<Section> {
    val arc = PI.toFloat() * r
    return listOf(
        // The top side, left to right.
        Section(
            path = Path().apply { moveTo(r - OVERLAP, 0f); lineTo(w - r + OVERLAP, 0f) },
            start = 0f, length = straight, straight = true,
            ax = r - OVERLAP, ay = 0f, bx = w - r + OVERLAP, by = 0f,
        ),
        // The right end, from the top round to the bottom.
        Section(
            path = Path().apply { arcTo(Rect(w - 2f * r, 0f, w, h), -90f, 180f, true) },
            start = straight, length = arc, straight = false,
            cx = w - r, cy = r, radius = r, firstDegrees = -90f,
        ),
        // The bottom side, right to left.
        Section(
            path = Path().apply { moveTo(w - r + OVERLAP, h); lineTo(r - OVERLAP, h) },
            start = straight + arc, length = straight, straight = true,
            ax = w - r + OVERLAP, ay = h, bx = r - OVERLAP, by = h,
        ),
        // The left end, from the bottom round to the top.
        Section(
            path = Path().apply { arcTo(Rect(0f, 0f, 2f * r, h), 90f, 180f, true) },
            start = 2f * straight + arc, length = arc, straight = false,
            cx = r, cy = r, radius = r, firstDegrees = 90f,
        ),
    )
}

// ---------------------------------------------------------------------------
// One light

/** A head at [head] and, behind it, [tail] of light that fades to nothing; [hue] is where in the palette its head is. */
private class Comet(
    val perimeter: Float,
    val head: Float,
    val tail: Float,
    val strength: Float,
    val hue: Float,
) {
    /**
     * The light at distance [s] along the outline: nothing ahead of the head, the
     * brightest at the head, and fading to nothing at [reachOf] of the tail.
     */
    fun colourAt(s: Float, alpha: Float, whiten: Float, reachOf: Float): Color {
        val length = tail * reachOf
        val behind = (((head - s) % perimeter) + perimeter) % perimeter
        if (behind > length) return palette(hue).copy(alpha = 0f)
        val u = behind / length
        val base = palette(hue + u * SPREAD * reachOf)
        val colour = if (whiten > 0f) lerp(base, Color.White, whiten) else base
        return colour.copy(alpha = ((1f - u).pow(1.5f) * strength * alpha).coerceIn(0f, 1f))
    }

    /** Whether any of the light falls between [from] and [to] along the outline. */
    fun touches(from: Float, to: Float, reachOf: Float): Boolean {
        val length = tail * reachOf
        for (shift in -1..1) {
            val end = head + shift * perimeter
            if (end >= from && end - length <= to) return true
        }
        return false
    }
}

/**
 * Lays one light down, in one width, along every stretch of the outline it
 * touches: each stretch one stroke, filled with one gradient.
 */
private fun DrawScope.paint(
    sections: List<Section>,
    comet: Comet,
    width: Float,
    alpha: Float,
    whiten: Float,
    reachOf: Float,
    blend: BlendMode,
) {
    for (section in sections) {
        val from = if (section.straight) section.start - OVERLAP else section.start
        val to = if (section.straight) section.start + section.length + OVERLAP else section.start + section.length
        if (!comet.touches(from, to, reachOf)) continue
        val brush = if (section.straight) {
            Brush.linearGradient(
                *straightStops(comet, section, alpha, whiten, reachOf),
                start = Offset(section.ax, section.ay),
                end = Offset(section.bx, section.by),
            )
        } else {
            Brush.sweepGradient(
                *capStops(comet, section, alpha, whiten, reachOf),
                center = Offset(section.cx, section.cy),
            )
        }
        drawPath(
            path = section.path,
            brush = brush,
            style = Stroke(width = width, cap = StrokeCap.Butt),
            blendMode = blend,
        )
    }
}

/**
 * How far past the head the light takes to go dark: a short, soft leading edge,
 * so the head is a clean end to the light and not a point on it.
 */
private const val HEAD_EDGE = 7f

private fun straightStops(
    comet: Comet,
    section: Section,
    alpha: Float,
    whiten: Float,
    reachOf: Float,
): Array<Pair<Float, Color>> {
    val from = section.start - OVERLAP
    val span = section.length + 2f * OVERLAP
    val ts = ArrayList<Float>(STRAIGHT_SAMPLES + 4)
    for (k in 0..STRAIGHT_SAMPLES) ts.add(k / STRAIGHT_SAMPLES.toFloat())
    for (shift in -1..1) {
        val at = comet.head + shift * comet.perimeter
        if (at >= from && at <= from + span) {
            ts.add((at - from) / span)
            val past = (at + HEAD_EDGE - from) / span
            if (past <= 1f) ts.add(past)
        }
    }
    ts.sort()
    return Array(ts.size) { i ->
        val t = ts[i].coerceIn(0f, 1f)
        t to comet.colourAt(from + t * span, alpha, whiten, reachOf)
    }
}

private fun capStops(
    comet: Comet,
    section: Section,
    alpha: Float,
    whiten: Float,
    reachOf: Float,
): Array<Pair<Float, Color>> {
    val arc = section.length
    // Where on a sweep gradient (0 at three o'clock, once round clockwise) the
    // point [c] along this half circle is.
    fun sweepOf(c: Float): Float {
        val degrees = section.firstDegrees + c / section.radius * (180f / PI.toFloat())
        return (((degrees % 360f) + 360f) % 360f) / 360f
    }

    val stops = ArrayList<Pair<Float, Color>>(CAP_SAMPLES + 8)
    for (k in 0..CAP_SAMPLES) {
        val c = arc * k / CAP_SAMPLES
        stops.add(sweepOf(c) to comet.colourAt(section.start + c, alpha, whiten, reachOf))
    }
    for (shift in -1..1) {
        val at = comet.head + shift * comet.perimeter
        if (at >= section.start && at <= section.start + arc) {
            val c = at - section.start
            stops.add(sweepOf(c) to comet.colourAt(at, alpha, whiten, reachOf))
            if (c + HEAD_EDGE <= arc) {
                stops.add(sweepOf(c + HEAD_EDGE) to comet.colourAt(at + HEAD_EDGE, alpha, whiten, reachOf))
            }
        }
    }
    // Three o'clock is where a sweep gradient starts and ends: the right half
    // circle goes through it, so it needs the same colour at both ends.
    if (section.firstDegrees < 0f) {
        val across = comet.colourAt(section.start + arc / 2f, alpha, whiten, reachOf)
        stops.add(0f to across)
        stops.add(1f to across)
    }
    stops.sortBy { it.first }
    return stops.toTypedArray()
}

private const val STRAIGHT_SAMPLES = 22
private const val CAP_SAMPLES = 14

// ---------------------------------------------------------------------------
// Colour and motion

/**
 * A colour from a ring of colours, [t] being how far round it is (1 is the
 * start again): blue, violet, pink, amber, green, cyan, blue.
 */
private fun palette(t: Float): Color {
    val x = (((t % 1f) + 1f) % 1f) * (PALETTE.size - 1)
    val i = x.toInt().coerceAtMost(PALETTE.size - 2)
    return lerp(PALETTE[i], PALETTE[i + 1], x - i)
}

private val PALETTE = listOf(
    Color(0xFF4285F4), // blue
    Color(0xFF9B6BFF), // violet
    Color(0xFFFF4D8D), // pink
    Color(0xFFFFB02E), // amber
    Color(0xFF34D27B), // green
    Color(0xFF22D3EE), // cyan
    Color(0xFF4285F4), // blue again: the ring closes
)

/** The tube's own thickness: thin. Everything else is a multiple of it. */
private val CORE = 1.5.dp

/** How much of the palette one light shows along its length. */
private const val SPREAD = 0.55f

/** Laps a second: the floor, what the level adds, and what a beat adds on top. */
private const val BASE_LAPS = 0.45f
private const val LEVEL_LAPS = 0.90f
private const val KICK_LAPS = 1.80f

/** Runs of the palette a second, the same way. */
private const val BASE_DRIFT = 0.22f
private const val LEVEL_DRIFT = 0.40f
private const val KICK_DRIFT = 0.80f
